class Player {
  String id, name, position, imageUrl;
  DateTime createdAt;

  Player({this.position, this.id, this.imageUrl, this.name, this.createdAt});
}
