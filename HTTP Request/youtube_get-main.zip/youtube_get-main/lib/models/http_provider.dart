import 'package:flutter/material.dart';

class HttpProvider with ChangeNotifier {}
