class HttpStateful {}
