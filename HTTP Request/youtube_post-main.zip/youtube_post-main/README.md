# youtube_post

Berikut merupakan bahan ajar tutorial flutter pada kanal youtube tentang http request metode post.

Petunjuk penggunaan :

1. Jangan replace file pubspec.yaml kalian dengan file pubscpec.yaml ini.
2. Buka file pubspec.yaml kalian
3. Tambahkan dependencies yang akan digunakan, mengikuti dengan file pubscpec.yaml ini.
4. Kalian bisa replace folder lib project dengan folder lib ini atau kalian juga bisa menyalin code-codenya saja.
