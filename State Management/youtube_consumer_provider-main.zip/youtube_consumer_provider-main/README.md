# youtube_consumer_provider

Berikut merupakan bahan ajar tutorial flutter pada kanal youtube tentang penggunaan consumer dan provider.

Petunjuk penggunaan :

1. Copy folder assets ke dalam project kalian.
2. Posisi folder assets sejajar dengan folder lib (root).
3. Jangan replace file pubspec.yaml kalian dengan file pubscpec.yaml ini.
4. Buka file pubspec.yaml kalian
5. Tambahkan font dan dependencies, mengikuti dengan file pubscpec.yaml ini.
6. Kalian bisa replace folder lib project dengan folder lib ini atau kalian juga bisa menyalin code-codenya saja.
